
export interface DocumentComment {
  id?: string;
  documentId?: string;
  comment?: string;
  createdBy?: string;
  createdDate?: Date;
  createdByName?:string;
}
