export interface OnlineUser {
  email: string;
  id: string;
  connectionId: string;
}
