export enum Quarter {
    Quarter1 = 0,
    Quarter2 = 1,
    Quarter3 = 2,
    Quarter4 = 3,
}