export interface Claim{
  claimType: string;
  claimValue: string;
}
