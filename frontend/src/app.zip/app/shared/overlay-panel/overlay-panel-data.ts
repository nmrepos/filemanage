import { InjectionToken } from '@angular/core';

export const OVERLAY_PANEL_DATA = new InjectionToken<any>('OVERLAY_PANEL_DATA');
